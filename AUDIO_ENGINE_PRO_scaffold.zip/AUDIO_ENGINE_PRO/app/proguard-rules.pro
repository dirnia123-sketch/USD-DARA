# حماية دوال JNI من R8 (انظر القسم 10 من المواصفات)
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.audioengine.pro.NativeEngine { *; }
-keep class com.audioengine.pro.EngineStats { *; }
