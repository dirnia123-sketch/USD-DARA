#include "AudioEngine.h"

#include <android/log.h>

#include <algorithm>
#include <cmath>

#define LOG_TAG "AudioEnginePro"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
constexpr double kTwoPi = 6.283185307179586476925286766559;
constexpr float kMinGainDb = -60.0f;
constexpr float kMaxGainDb = -6.0f;     // سقف أمان لحماية السمع في الاختبار
constexpr float kGainSmoothing = 0.002f; // تنعيم لتفادي الطقطقة
}  // namespace

bool AudioEngine::start() {
    std::lock_guard<std::mutex> lock(mutex_);
    wanted_.store(true);
    return openAndStartLocked();
}

void AudioEngine::stop() {
    wanted_.store(false);
    std::lock_guard<std::mutex> lock(mutex_);
    closeLocked();
}

bool AudioEngine::isRunning() {
    std::lock_guard<std::mutex> lock(mutex_);
    return stream_ && stream_->getState() == oboe::StreamState::Started;
}

void AudioEngine::setFrequency(float hz) {
    frequencyHz_.store(std::clamp(hz, 20.0f, 20000.0f));
}

void AudioEngine::setGainDb(float db) {
    const float clamped = std::clamp(db, kMinGainDb, kMaxGainDb);
    gainLinear_.store(std::pow(10.0f, clamped / 20.0f));
}

bool AudioEngine::openAndStartLocked() {
    if (stream_) return true;

    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(2)
            ->setUsage(oboe::Usage::Media)
            ->setContentType(oboe::ContentType::Music)
            ->setDataCallback(shared_from_this())
            ->setErrorCallback(shared_from_this());

    oboe::Result result = builder.openStream(stream_);
    if (result != oboe::Result::OK) {
        LOGE("openStream failed: %s", oboe::convertToText(result));
        stream_.reset();
        return false;
    }

    phase_ = 0.0;
    smoothedGain_ = 0.0f;  // fade-in

    result = stream_->requestStart();
    if (result != oboe::Result::OK) {
        LOGE("requestStart failed: %s", oboe::convertToText(result));
        stream_->close();
        stream_.reset();
        return false;
    }

    LOGI("stream started: rate=%d burst=%d buffer=%d channels=%d",
         stream_->getSampleRate(), stream_->getFramesPerBurst(),
         stream_->getBufferSizeInFrames(), stream_->getChannelCount());
    return true;
}

void AudioEngine::closeLocked() {
    if (!stream_) return;
    stream_->stop();
    stream_->close();
    stream_.reset();
}

oboe::DataCallbackResult AudioEngine::onAudioReady(oboe::AudioStream *stream,
                                                   void *audioData,
                                                   int32_t numFrames) {
    auto *out = static_cast<float *>(audioData);
    const int channels = stream->getChannelCount();
    const double sampleRate = static_cast<double>(stream->getSampleRate());
    const double phaseInc = kTwoPi * frequencyHz_.load(std::memory_order_relaxed) / sampleRate;
    const float targetGain = gainLinear_.load(std::memory_order_relaxed);

    for (int32_t i = 0; i < numFrames; ++i) {
        smoothedGain_ += (targetGain - smoothedGain_) * kGainSmoothing;
        const float sample = static_cast<float>(std::sin(phase_)) * smoothedGain_;
        for (int c = 0; c < channels; ++c) {
            out[i * channels + c] = sample;
        }
        phase_ += phaseInc;
        if (phase_ >= kTwoPi) phase_ -= kTwoPi;
    }
    return oboe::DataCallbackResult::Continue;
}

// تستدعيها Oboe من خيط مستقل (ليس خيط الصوت)، فإعادة الفتح هنا آمنة.
void AudioEngine::onErrorAfterClose(oboe::AudioStream * /*stream*/, oboe::Result error) {
    LOGI("onErrorAfterClose: %s", oboe::convertToText(error));
    if (error == oboe::Result::ErrorDisconnected && wanted_.load()) {
        std::lock_guard<std::mutex> lock(mutex_);
        stream_.reset();
        restartCount_.fetch_add(1);
        if (wanted_.load()) openAndStartLocked();
    }
}

void AudioEngine::getStats(int32_t *out) {
    std::fill(out, out + kStatsSize, 0);
    std::lock_guard<std::mutex> lock(mutex_);
    out[8] = restartCount_.load();
    if (!stream_) return;

    out[0] = (stream_->getState() == oboe::StreamState::Started) ? 1 : 0;
    auto xrun = stream_->getXRunCount();
    out[1] = xrun ? xrun.value() : 0;
    out[2] = stream_->getSampleRate();
    out[3] = stream_->getFramesPerBurst();
    out[4] = stream_->getBufferSizeInFrames();
    out[5] = stream_->getChannelCount();
    out[6] = static_cast<int32_t>(stream_->getPerformanceMode());
    out[7] = static_cast<int32_t>(stream_->getSharingMode());
}
