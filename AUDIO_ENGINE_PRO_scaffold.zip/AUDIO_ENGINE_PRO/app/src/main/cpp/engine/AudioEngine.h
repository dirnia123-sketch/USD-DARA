#pragma once

#include <oboe/Oboe.h>

#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>

// محرك صوت أولي (المرحلة 2): نغمة جيبية عبر Oboe مع قياس XRun.
// قواعد الـ callback: لا mutex، لا تخصيص ذاكرة، لا I/O.
// المعاملات تنتقل من الواجهة عبر std::atomic.
class AudioEngine : public oboe::AudioStreamDataCallback,
                    public oboe::AudioStreamErrorCallback,
                    public std::enable_shared_from_this<AudioEngine> {
public:
    // ترتيب الإحصاءات: running, xruns, sampleRate, framesPerBurst,
    // bufferFrames, channels, performanceMode, sharingMode, restarts
    static constexpr int kStatsSize = 9;

    bool start();
    void stop();
    bool isRunning();
    void setFrequency(float hz);
    void setGainDb(float db);
    void getStats(int32_t *out);

    // Oboe callbacks
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream *stream,
                                          void *audioData,
                                          int32_t numFrames) override;
    void onErrorAfterClose(oboe::AudioStream *stream, oboe::Result error) override;

private:
    bool openAndStartLocked();
    void closeLocked();

    std::mutex mutex_;                       // مسار التحكم فقط، لا يُستخدم في callback
    std::shared_ptr<oboe::AudioStream> stream_;
    std::atomic<bool> wanted_{false};
    std::atomic<float> frequencyHz_{440.0f};
    std::atomic<float> gainLinear_{0.1f};    // -20 dB
    std::atomic<int32_t> restartCount_{0};

    // حالة خيط الصوت فقط
    double phase_ = 0.0;
    float smoothedGain_ = 0.0f;
};
