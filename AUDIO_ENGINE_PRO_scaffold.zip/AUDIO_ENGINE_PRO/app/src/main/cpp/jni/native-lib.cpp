#include <jni.h>

#include <memory>

#include "AudioEngine.h"

namespace {
std::shared_ptr<AudioEngine> &engine() {
    // enable_shared_from_this يتطلب shared_ptr
    static std::shared_ptr<AudioEngine> instance = std::make_shared<AudioEngine>();
    return instance;
}
}  // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_audioengine_pro_NativeEngine_nativeStart(JNIEnv *, jobject) {
    return engine()->start() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_audioengine_pro_NativeEngine_nativeStop(JNIEnv *, jobject) {
    engine()->stop();
}

JNIEXPORT jboolean JNICALL
Java_com_audioengine_pro_NativeEngine_nativeIsRunning(JNIEnv *, jobject) {
    return engine()->isRunning() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_audioengine_pro_NativeEngine_nativeSetFrequency(JNIEnv *, jobject, jfloat hz) {
    engine()->setFrequency(hz);
}

JNIEXPORT void JNICALL
Java_com_audioengine_pro_NativeEngine_nativeSetGainDb(JNIEnv *, jobject, jfloat db) {
    engine()->setGainDb(db);
}

JNIEXPORT jintArray JNICALL
Java_com_audioengine_pro_NativeEngine_nativeGetStats(JNIEnv *env, jobject) {
    jint values[AudioEngine::kStatsSize];
    engine()->getStats(reinterpret_cast<int32_t *>(values));
    jintArray result = env->NewIntArray(AudioEngine::kStatsSize);
    if (result != nullptr) {
        env->SetIntArrayRegion(result, 0, AudioEngine::kStatsSize, values);
    }
    return result;
}

}  // extern "C"
