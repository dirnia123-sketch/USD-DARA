cmake_minimum_required(VERSION 3.22.1)
project(audioenginepro LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Oboe يأتي كـ Prefab package عبر Gradle (buildFeatures.prefab = true)
find_package(oboe REQUIRED CONFIG)

add_library(audioenginepro SHARED
        jni/native-lib.cpp
        engine/AudioEngine.cpp)

target_include_directories(audioenginepro PRIVATE engine)

target_compile_options(audioenginepro PRIVATE -Wall -Wextra -O2)

# محاذاة صفحات 16 KB (انظر القسم 6 من المواصفات)
target_link_options(audioenginepro PRIVATE "-Wl,-z,max-page-size=16384")

target_link_libraries(audioenginepro
        oboe::oboe
        android
        log)
