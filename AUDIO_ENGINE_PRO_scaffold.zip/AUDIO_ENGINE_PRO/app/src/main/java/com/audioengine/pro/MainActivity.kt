package com.audioengine.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding
import com.audioengine.pro.ui.EngineScreen

class MainActivity : ComponentActivity() {

    // لاستئناف التشغيل بعد العودة للتطبيق (المرحلة 2: إيقاف/استئناف)
    private var wasRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val colors = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = colors) {
                Scaffold { innerPadding ->
                    EngineScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (wasRunning) {
            NativeEngine.nativeStart()
            wasRunning = false
        }
    }

    override fun onStop() {
        super.onStop()
        if (NativeEngine.nativeIsRunning()) {
            wasRunning = true
            NativeEngine.nativeStop()
        }
    }
}
