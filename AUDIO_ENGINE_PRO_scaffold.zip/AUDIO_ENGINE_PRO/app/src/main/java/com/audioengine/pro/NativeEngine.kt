package com.audioengine.pro

/** جسر JNI إلى محرك C++/Oboe. */
object NativeEngine {
    init {
        System.loadLibrary("audioenginepro")
    }

    external fun nativeStart(): Boolean
    external fun nativeStop()
    external fun nativeIsRunning(): Boolean
    external fun nativeSetFrequency(hz: Float)
    external fun nativeSetGainDb(db: Float)
    external fun nativeGetStats(): IntArray

    fun stats(): EngineStats {
        val a = nativeGetStats()
        return EngineStats(
            running = a[0] == 1,
            xruns = a[1],
            sampleRate = a[2],
            framesPerBurst = a[3],
            bufferFrames = a[4],
            channels = a[5],
            performanceMode = a[6],
            sharingMode = a[7],
            restarts = a[8],
        )
    }
}

data class EngineStats(
    val running: Boolean = false,
    val xruns: Int = 0,
    val sampleRate: Int = 0,
    val framesPerBurst: Int = 0,
    val bufferFrames: Int = 0,
    val channels: Int = 0,
    val performanceMode: Int = 0,
    val sharingMode: Int = 0,
    val restarts: Int = 0,
) {
    // قيم oboe::PerformanceMode
    val performanceName: String
        get() = when (performanceMode) {
            10 -> "None"
            11 -> "PowerSaving"
            12 -> "LowLatency"
            else -> "-"
        }

    // قيم oboe::SharingMode
    val sharingName: String
        get() = when (sharingMode) {
            0 -> "Exclusive"
            1 -> "Shared"
            else -> "-"
        }
}
