package com.audioengine.pro.ui

import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.audioengine.pro.EngineStats
import com.audioengine.pro.NativeEngine
import com.audioengine.pro.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun EngineScreen(modifier: Modifier = Modifier) {
    var stats by remember { mutableStateOf(EngineStats()) }
    var frequency by remember { mutableFloatStateOf(440f) }
    var gainDb by remember { mutableFloatStateOf(-20f) }
    var startedAtMs by remember { mutableLongStateOf(0L) }
    var elapsedSec by remember { mutableLongStateOf(0L) }

    // استطلاع الإحصاءات كل نصف ثانية خارج خيط الصوت
    LaunchedEffect(Unit) {
        while (true) {
            val s = withContext(Dispatchers.Default) { NativeEngine.stats() }
            val now = SystemClock.elapsedRealtime()
            if (s.running) {
                if (startedAtMs == 0L) startedAtMs = now
                elapsedSec = (now - startedAtMs) / 1000
            } else {
                startedAtMs = 0L
                elapsedSec = 0L
            }
            stats = s
            delay(500)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.title), style = MaterialTheme.typography.headlineSmall)
        Text(stringResource(R.string.warning), style = MaterialTheme.typography.bodyMedium)

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (stats.running) NativeEngine.nativeStop() else NativeEngine.nativeStart()
                stats = NativeEngine.stats()
            },
        ) {
            Text(stringResource(if (stats.running) R.string.btn_stop else R.string.btn_start))
        }

        Text(stringResource(R.string.label_freq, frequency.toInt()))
        Slider(
            value = frequency,
            onValueChange = {
                frequency = it
                NativeEngine.nativeSetFrequency(it)
            },
            valueRange = 100f..2000f,
        )

        Text(stringResource(R.string.label_gain, gainDb.toInt()))
        Slider(
            value = gainDb,
            onValueChange = {
                gainDb = it
                NativeEngine.nativeSetGainDb(it)
            },
            valueRange = -60f..-6f,
        )

        val state = stringResource(if (stats.running) R.string.state_running else R.string.state_stopped)
        Text(stringResource(R.string.stat_state, state))
        Text(stringResource(R.string.stat_elapsed, elapsedSec.toInt()))
        Text(stringResource(R.string.stat_xrun, stats.xruns))
        Text(stringResource(R.string.stat_rate, stats.sampleRate))
        Text(stringResource(R.string.stat_channels, stats.channels))
        Text(stringResource(R.string.stat_burst, stats.framesPerBurst))
        Text(stringResource(R.string.stat_buffer, stats.bufferFrames))
        Text(stringResource(R.string.stat_perf, stats.performanceName))
        Text(stringResource(R.string.stat_sharing, stats.sharingName))
        Text(stringResource(R.string.stat_restarts, stats.restarts))
    }
}
