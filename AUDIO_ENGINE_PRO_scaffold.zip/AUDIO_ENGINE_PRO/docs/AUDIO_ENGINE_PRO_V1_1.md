# AUDIO ENGINE PRO V1.1

## مخطط هندسي ومواصفات تنفيذ مشروع Android (نسخة مصححة)

**الحالة:** مواصفات معدّلة --- Scaffold تنفيذي مطلوب\
**المنصة:** Android 13+ (minSdk 33)\
**الصلاحيات:** بدون Root\
**اللغات:** Kotlin + C++\
**محرك الصوت:** Oboe / AAudio\
**المخارج المستهدفة:** USB DAC، السماعات السلكية، مكبر الهاتف، Bluetooth

> **تنبيه هندسي مهم:** هذا الملف يصف مشروعاً قابلاً للتحويل إلى Android
> Studio project، لكنه ليس بحد ذاته مشروع APK قابلاً للبناء. ملف Markdown
> لا يحتوي على ملفات Gradle وManifest وCMake ومصادر Kotlin/C++ اللازمة
> للبناء. كما أن APK عادي دون Root لا يستطيع فرض معالجة صوت جميع
> التطبيقات أو استبدال Audio HAL/Audio Policy. يمكنه معالجة صوت التطبيق
> نفسه، والتقاط صوت التطبيقات الأخرى فقط عندما تسمح سياسات Android
> والتطبيق المصدر بذلك.

> **ملاحظة V1.1:** كل التعديلات عن V1.0 مسجلة في القسم 13 بالترتيب،
> وكل تعديل مشار إليه في مكانه بالوسم **[تعديل N]**.

------------------------------------------------------------------------

# 1. الهدف ونطاق الإصدار

بناء تطبيق صوت احترافي يتضمن محرك معالجة مستقل داخل التطبيق، ومشغل
مصادر صوت داخلي، وواجهة لإدارة التطبيقات، ومسار التقاط محدود وفق واجهات
Android العامة، وإدارة مخارج الصوت المتاحة.

## 1.1 الأهداف

-   محرك PCM أصلي مكتوب بلغة C++.
-   استخدام Oboe (فوق AAudio) لفتح تدفقات صوت منخفضة التأخير.
-   معالجة صوت التطبيق نفسه ومصادر الصوت التي يمكن التقاطها قانونياً
    وتقنياً.
-   إدارة قائمة التطبيقات التي يرغب المستخدم في فحص توافقها أو التقاط
    صوتها.
-   DSP: Equalizer وMixer وCompressor وLimiter وFilters وSpectrum
    Analyzer.
-   اكتشاف أجهزة USB Audio وBluetooth والسماعات ومكبر الهاتف.
-   بناء APK بواسطة GitHub Actions.

## 1.2 ما لا يعد به الإصدار

-   لا يحقن التطبيق نفسه داخل تطبيقات أخرى.
-   لا يجبر تطبيقاً آخر على إرسال صوته إلى محركنا.
-   لا يتجاوز `allowAudioPlaybackCapture` أو سياسات منع الالتقاط.
-   لا يستبدل Audio HAL أو Audio Policy من APK عادي.
-   لا يضمن أن كل جهاز USB DAC أو Bluetooth يدعم كل Sample Rate أو عدد
    قنوات.
-   اختيار مخرج داخل تطبيقنا لا يغير بالضرورة مخرج التطبيقات الأخرى.
-   **[تعديل 5]** لا يلتقط المكالمات الهاتفية ولا المحتوى المحمي
    بـ DRM، ولا يلتقط إلا الاستخدامات `MEDIA` و`GAME` و`UNKNOWN`.
-   **[تعديل 5]** غير موصى به مع الفيديو: مسار الالتقاط يضيف زمن تأخير
    يسبب عدم تزامن الصوت والصورة، ولا يمكن تعويضه في التطبيق المصدر.
-   **[تعديل 3]** لا يكتم صوت التطبيق المصدر الأصلي أثناء الالتقاط
    (انظر 2.2).

------------------------------------------------------------------------

# 2. المعمارية

``` text
AUDIO ENGINE PRO UI (Kotlin / Compose)
        |
        +-- Application Manager
        +-- Capture Permission / Session Manager
        +-- Audio Device Manager
        +-- Audio Source Manager (ملفات / فك ترميز)      [تعديل 8]
        +-- Audio Focus + MediaSession                    [تعديل 9]
        +-- Preset & Settings Store
        |
        +-- Foreground Services                           [تعديل 1]
        |     +-- PlaybackService (mediaPlayback)
        |     +-- CaptureService  (mediaProjection)
        |
        v
JNI BRIDGE
        |
        v
NATIVE AUDIO ENGINE (C++ / Oboe)
        |
        +-- Lock-free Ring Buffer (SPSC)                  [تعديل 10]
        +-- Drift Compensation / Resampler                [تعديل 10]
        +-- Audio Stream (Oboe)
        +-- PCM Pipeline
        +-- Mixer
        +-- Parametric / Graphic EQ
        +-- Compressor
        +-- Limiter
        +-- Filters
        +-- Metering / FFT
        |
        v
ANDROID AUDIO OUTPUT
        |
        +-- Built-in speaker / wired headset
        +-- USB Audio device (بحسب دعم Android والجهاز)
        +-- Bluetooth route (بحسب ملف الجهاز وسياسة النظام)
```

## 2.1 المسار A: صوت داخلي

مصدر الصوت داخل AUDIO ENGINE PRO (ملف محلي يفك ترميزه
Audio Source Manager) → Ring Buffer → محرك C++/Oboe → DSP → مخرج
Android المختار.

هذا هو المسار الأساسي الذي يمكن التحكم فيه بالكامل داخل حدود التطبيق.
**[تعديل 8]** تفاصيل المصدر في 3.2.

## 2.2 المسار B: التقاط صوت تطبيق آخر

تطبيق مصدر متوافق → `MediaProjection` وموافقة المستخدم →
`AudioPlaybackCapture` → `AudioRecord` → Ring Buffer → Drift
Compensation → DSP → مخرج التطبيق.

نجاح هذا المسار مشروط بإصدار Android، وموافقة المستخدم، وصلاحيات
التسجيل، وسياسة التقاط الصوت في التطبيق المصدر. بعض التطبيقات تمنع
الالتقاط أو لا تسمح به.

### قواعد إلزامية للمسار B

1.  **[تعديل 2] منع حلقة التغذية الراجعة:** يجب ألا يلتقط التطبيق صوته
    المعالَج. استخدم `excludeUid(Process.myUid())` أو استخدم
    `addMatchingUid` للتطبيقات المستهدفة فقط (فيستثنى تطبيقنا ضمنياً).
    تحقق من وثائق الإصدار المستهدف عن إمكانية الجمع بين قواعد التضمين
    والاستثناء في نفس الإعداد.
2.  **[تعديل 4] الالتقاط لكل تطبيق:** معالجة DSP مستقلة لكل تطبيق تعني
    `AudioRecord` منفصلاً لكل UID. في V1.0/V1.1 اعتمد معالجة موحدة لجلسة
    التقاط واحدة، واجعل الالتقاط لكل تطبيق هدفاً لاحقاً بعد اختبار
    الجدوى.
3.  **[تعديل 3] الصوت المزدوج:** يبقى صوت التطبيق المصدر مسموعاً عبر
    مساره الأصلي إلى جانب الصوت المعالَج. لا يمكن كتمه دون Root. يجب أن
    تعرض الواجهة تحذيراً واضحاً، وأن توثق الإعدادات الموصى بها (مثلاً
    توجيه مخرج التطبيق المصدر إلى جهاز مختلف عند الإمكان).
4.  **[تعديل 6] نص الموافقة:** نافذة MediaProjection تذكر مشاركة/تسجيل
    الشاشة حتى لو كان الالتقاط صوتاً فقط. اعرض شاشة شرح قبل ظهور النافذة
    توضح أن التطبيق لا يسجل الشاشة وأن الغرض هو التقاط الصوت.
5.  **الموافقة لا تُعاد استخدامها:** في Android 14 وما بعده لا تعتمد على
    إعادة استخدام نفس الموافقة لجلسات التقاط متعددة. اطلب موافقة جديدة
    عند كل جلسة، وسجّل `MediaProjection.Callback` للتعامل مع الإيقاف.
6.  **الخدمة:** يجب بدء `CaptureService` كخدمة Foreground بنوع
    `mediaProjection` قبل إنشاء الـ projection (انظر 6.1).
7.  **صيغة الالتقاط:** اطلب 48 kHz Stereo، وابدأ بـ PCM 16-bit ثم اختبر
    دعم Float على الأجهزة. حوّل داخلياً إلى Float 32 مع Dither عند
    الرجوع إلى 16-bit.

### مثال إعداد الالتقاط (Kotlin)

``` kotlin
val config = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
    .addMatchingUsage(AudioAttributes.USAGE_GAME)
    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
    .excludeUid(Process.myUid())   // تحقق من التوافق مع قواعد التضمين
    .build()

val record = AudioRecord.Builder()
    .setAudioPlaybackCaptureConfig(config)
    .setAudioFormat(
        AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(48000)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()
    )
    .build()
```

## 2.3 المسار C: تكامل نظامي مستقبلي

قد يتطلب بناء AOSP مخصصاً وتعديلات Audio Policy وAudio HAL. هذا ليس جزءاً
من APK V1.1 ولا يتطلبه مسار البناء العادي.

------------------------------------------------------------------------

# 3. الوظائف

## 3.1 Application Manager

-   عرض التطبيقات المثبتة التي يمكن إظهارها وفق قواعد Android.
-   **[تعديل 7]** رؤية الحزم من Android 11 مقيدة. استخدم عناصر
    `<queries>` في Manifest لتطبيقات محددة (مثل مشغلات الوسائط عبر
    intent filter)، أو استخدم `QUERY_ALL_PACKAGES` فقط إذا كان التوزيع
    خارج Google Play أو حصلت على استثناء، لأنه إذن مقيّد في السياسة.
-   إضافة/إزالة التطبيق من قائمة المفضلة أو قائمة فحص التوافق.
-   إظهار حالة التقاط الصوت: غير مفحوص، متاح، غير مسموح، أو فشل.
-   إعدادات DSP مستقلة لكل جلسة يملكها التطبيق. **[تعديل 4]** لا تعني
    الجلسة هنا «تطبيقاً خارجياً» إلا بعد تنفيذ الالتقاط لكل UID.
-   عدم عرض حالة «معالجة النظام» لمجرد إضافة التطبيق إلى القائمة.

## 3.2 Audio Source Manager (جديد) **[تعديل 8]**

يعرّف مصدر الصوت الداخلي للمسار A:

-   منتقي ملفات (Storage Access Framework) دون أذونات تخزين واسعة.
-   فك الترميز عبر `MediaExtractor` + `MediaCodec` (أو ExoPlayer/Media3
    إذا قُرر ذلك)، مع خرج PCM يُدفع في Ring Buffer.
-   الصيغ المستهدفة للاختبار: MP3 وAAC وFLAC وWAV وOGG.
-   إدارة قائمة التشغيل، والبحث (seek)، والإيقاف المؤقت، وتكرار التشغيل.
-   خيط فك الترميز منفصل عن خيط callback الصوتي ولا يحجبه.
-   معالجة اختلاف معدل عينة الملف عن معدل الـ stream عبر Resampler.

## 3.3 Native Audio Engine

-   فتح/إغلاق Audio Stream.
-   تهيئة القنوات ومعدل العينة وفق قدرات المسار الفعلي.
-   استخدام Float PCM داخلياً حيث يكون مناسباً.
-   Audio callback قصير وغير حاجب.
-   تجنب تخصيص الذاكرة، والملفات، وعمليات I/O، والأقفال غير الضرورية
    داخل callback.
-   **[تعديل 10]** الاتصال بين الخيوط (فك الترميز/الالتقاط ← callback)
    عبر Lock-free SPSC Ring Buffer، وتحديث معاملات DSP من الواجهة عبر
    `std::atomic` أو قوائم أوامر lock-free، لا عبر mutex.
-   **[تعديل 10]** مسار B: ساعة `AudioRecord` وساعة مخرج Oboe مختلفتان،
    فيلزم مراقبة مستوى امتلاء الـ Ring Buffer وتعويض الانحراف
    (drift compensation) بإعادة أخذ عينات طفيفة، مع سياسة واضحة عند
    underrun/overrun.
-   **[تعديل 11]** التعامل مع انقطاع الجهاز: استخدم
    `onErrorAfterClose` في Oboe (خطأ `Disconnected`) وأعد فتح الـ stream
    من خيط مستقل لا من داخل الـ callback، وأعد تهيئة DSP بمعدل العينة
    الجديد.
-   تسجيل XRun وبيانات الأداء خارج callback.
-   رفع أولوية خيط الصوت عبر ما توفره Oboe، وعدم إنشاء خيوط داخل
    callback.

## 3.4 DSP

  الوحدة            النطاق الأولي
  ----------------- --------------------------------------
  Graphic EQ        31 نطاقاً
  Parametric EQ     تردد / Gain / Q
  Compressor        Threshold / Ratio / Attack / Release
  Limiter           Ceiling / Release / Look-ahead
  Bass Processing   Low Shelf مع خيار Harmonic Enhancer
  Stereo            Width / Balance
  FIR/IIR           فلاتر رقمية
  Spectrum          FFT ومقياس طيف
  Metering          Peak / RMS / True-peak
  Resampling        للتوافق ولتعويض الانحراف

### متطلبات DSP الإلزامية **[تعديل 12]**

-   **الفلاتر:** Biquad بمعاملات RBJ Cookbook، مع حساب المعاملات بدقة
    double وتشغيلها بـ float، والانتباه لثبات الفلاتر عند الترددات
    المنخفضة جداً.
-   **تنعيم المعاملات (Parameter Smoothing):** أي تغيير في Gain أو تردد
    أو Q يُنفَّذ بتدرج لتفادي طقطقة zipper noise.
-   **Denormals:** تفعيل flush-to-zero على ARM أو إضافة إزاحة صغيرة في
    مسارات التغذية الراجعة.
-   **Gain staging:** Pre-gain قبل EQ يعوّض الرفع الأقصى للنطاقات
    لمنع clipping، وLimiter في نهاية السلسلة دائماً.
-   **Limiter:** Look-ahead يضيف زمن تأخير يجب حسابه وعرضه في الواجهة،
    وTrue-peak عند الحاجة (oversampling).
-   **Dither:** عند التحويل إلى 16-bit.
-   **FFT:** مكتبة محددة (مثل pffft أو KissFFT)، وخيط تحليل منفصل
    يكتب النتائج في بنية lock-free تقرؤها الواجهة دون تخصيص ذاكرة.
-   **FIR الطويلة:** تُنفَّذ بالتفاف مقسّم (partitioned convolution) وإلا
    تثقل الـ callback.
-   **Bass Processing:** يُعرَّف تقنياً كـ Low Shelf قابل للضبط، مع
    Harmonic Enhancer اختياري؛ لا يُترك وصفاً عاماً.
-   **تحسين الأداء:** NEON عند الحاجة بعد القياس، لا قبله.

يجب تنفيذ وحدات DSP تدريجياً واختبار استجابتها، وعدم تفعيل معالجة غير
مختبرة في المسار الحرج.

## 3.5 Output Device Manager

-   مراقبة اتصال وفصل أجهزة الصوت.
-   اكتشاف USB Audio عبر واجهات Android العامة.
-   الاستفادة من AudioDeviceCallback وAudioManager لاكتشاف التغييرات.
-   لا تضبط `setDeviceId` في Oboe إلا عند اختيار المستخدم صراحة؛ الافتراضي
    اتباع توجيه النظام.
-   إعادة تهيئة Audio Stream عند تغير الجهاز (انظر 3.3).
-   عدم افتراض أن اختيار جهاز في الواجهة يضمن توجيه كل تطبيقات النظام
    إليه.

### Bluetooth **[تعديل 13]**

-   زمن تأخير A2DP مرتفع (غالباً من مئة إلى عدة مئات ملّي ثانية بحسب
    الـ codec)، فلا يُعامل كمخرج منخفض التأخير، ويُعرض ذلك للمستخدم.
-   إذن `BLUETOOTH_CONNECT` مطلوب من Android 12 للتعامل مع أجهزة
    Bluetooth وأسمائها.
-   اختبار LE Audio عند توفره في الجهاز، وتوثيق السلوك.

### USB **[تعديل 14]**

-   في الوضع Shared يمرّ الصوت عبر mixer النظام، وقد يعيد النظام أخذ
    العينات إلى معدل آخر، فلا يُضمن Bit-perfect.
-   Android 14 أضاف واجهات لمعرفة وضبط سمات المزج (Mixer Attributes) تدعم
    Bit-perfect على أجهزة USB مدعومة؛ تحقق منها في وثائق `AudioManager`
    وجرّبها كخيار متقدم.
-   جرّب Exclusive عند الدعم، وتعامل مع رفض النظام له أو رجوعه إلى
    Shared.
-   تعامل مع طلب إذن USB للجهاز عند الحاجة لواجهات USB host.

## 3.6 Audio Focus والخدمات **[تعديل 9]**

-   طلب Audio Focus عند بدء التشغيل، والتعامل مع فقدانه (مؤقتاً أو
    دائماً) وخفض الصوت (ducking) وفق السلوك المناسب.
-   `MediaSession` وإشعار تشغيل بأزرار تحكم.
-   `PlaybackService` كخدمة Foreground بنوع `mediaPlayback`.
-   التعامل مع Doze وتحسين البطارية: توثيق سلوك التطبيق وطلب استثناء
    فقط عند الحاجة الفعلية.
-   التعامل مع `ACTION_AUDIO_BECOMING_NOISY` لإيقاف التشغيل عند سحب
    السماعات.

------------------------------------------------------------------------

# 4. إعدادات صوت أولية

هذه قيم بدء للاختبار وليست ضمانات لكل جهاز:

  الإعداد               القيمة
  --------------------- --------------------------------------------
  Sample Rate           Auto؛ ثم 44.1/48 kHz للاختبار
  Internal Format       Float 32-bit
  Channels              حسب المصدر والمخرج
  Buffer                يبدأ بـ Auto أو إعداد Oboe الافتراضي
  Performance Mode      Low Latency عند الإمكان
  Sharing Mode          Shared افتراضياً؛ تجربة Exclusive عند دعمها
  Clipping Protection   مفعّل
  Capture Format        48 kHz Stereo، PCM 16-bit ثم اختبار Float
  Output                يختاره المستخدم من الأجهزة المتاحة

لا تفرض 96 kHz أو buffer صغيراً على كل الأجهزة. الأولوية للاستقرار، ثم
قياس latency وتحسينه. بما أن minSdk هو 33 فـ AAudio متوفر دائماً ولا حاجة
لمسار OpenSL ES الاحتياطي **[تعديل 15]**.

------------------------------------------------------------------------

# 5. هيكل Android Studio المقترح **[تعديل 16]**

``` text
AUDIO_ENGINE_PRO/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradlew
├── gradlew.bat
├── .gitignore
├── gradle/
│   ├── libs.versions.toml
│   └── wrapper/
│       ├── gradle-wrapper.jar
│       └── gradle-wrapper.properties
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── res/
│       │   ├── java/com/audioengine/pro/
│       │   │   ├── MainActivity.kt
│       │   │   ├── ui/
│       │   │   ├── apps/
│       │   │   ├── capture/        (CaptureService, MediaProjection)
│       │   │   ├── playback/       (PlaybackService, MediaSession, Focus)
│       │   │   ├── source/         (Decoder, Playlist)
│       │   │   ├── devices/
│       │   │   └── settings/
│       │   └── cpp/
│       │       ├── CMakeLists.txt
│       │       ├── jni/native-lib.cpp
│       │       ├── engine/AudioEngine.{h,cpp}
│       │       ├── engine/AudioCallback.{h,cpp}
│       │       ├── engine/RingBuffer.h
│       │       ├── engine/DriftCompensator.{h,cpp}
│       │       └── dsp/DspChain.{h,cpp}, Biquad.h, Limiter.h, Fft.h
│       ├── test/                   (اختبارات JVM)
│       ├── androidTest/            (اختبارات على الجهاز)
│       └── cpp-tests/              (GoogleTest للـ DSP على المضيف)
└── .github/workflows/android-build.yml
```

يمكن تقسيم DSP وUSB وCapture إلى Gradle modules مستقلة بعد نجاح أول
نموذج. في بداية التنفيذ يفضّل إبقاء النواة صغيرة لتقليل أخطاء البناء.
ملاحظة: مجلد `tests/` في الجذر الموجود في V1.0 استُبدل ببنية الاختبار
القياسية لـ Android.

------------------------------------------------------------------------

# 6. متطلبات البناء

-   Android Studio بإصدار حديث متوافق مع Android Gradle Plugin المختار.
-   JDK مطابق لمتطلبات Gradle/AGP.
-   **[تعديل 1]** `compileSdk` و`targetSdk` بقيمة **34 أو أحدث**
    (مطلوب لأذونات خدمات Foreground الجديدة)، مع `minSdk = 33`. تحقق من
    متطلبات Google Play الحالية لـ targetSdk عند النشر.
-   Android NDK وCMake.
-   Oboe كمكتبة native عبر Gradle مع `buildFeatures { prefab = true }`
    **[تعديل 15]**.
-   `ndk { abiFilters += listOf("arm64-v8a") }` (مع x86_64 للمحاكي
    عند الحاجة) **[تعديل 15]**.
-   **[تعديل 15]** التحقق من محاذاة المكتبات الأصلية لصفحات 16 KB
    (مطلوبة للتطبيقات المستهدفة لإصدارات حديثة؛ راجع وثائق NDK الحالية
    لإصدار NDK المناسب).
-   GitHub Actions لبناء Debug APK.

**ملاحظة إصدارية:** يجب تثبيت إصدارات AGP وGradle وKotlin وNDK وOboe
المتوافقة عند إنشاء scaffold الفعلي، ومراجعة وثائقها الرسمية وقت
التنفيذ. لا تستخدم أرقام إصدارات عشوائية من هذا المستند.

## 6.1 إعدادات Android الضرورية **[تعديل 1]**

``` xml
<!-- الأذونات بحسب الميزات المفعلة -->
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>

<!-- ميزات اختيارية: لا تمنع التثبيت على أجهزة لا تدعمها -->
<uses-feature android:name="android.hardware.usb.host" android:required="false"/>
<uses-feature android:name="android.hardware.audio.low_latency" android:required="false"/>
<uses-feature android:name="android.hardware.audio.pro" android:required="false"/>

<service
    android:name=".capture.CaptureService"
    android:foregroundServiceType="mediaProjection"
    android:exported="false"/>
<service
    android:name=".playback.PlaybackService"
    android:foregroundServiceType="mediaPlayback"
    android:exported="false"/>
```

ملاحظات:

-   لا تضف أذونات غير لازمة؛ `BLUETOOTH_CONNECT` و`RECORD_AUDIO`
    تُطلب وقت التشغيل عند استخدام الميزة فقط.
-   `AudioPlaybackCapture` يحتاج موافقة MediaProjection وإعداد
    `AudioPlaybackCaptureConfiguration`، وليس مجرد إذن في Manifest.
-   إذن USB يُطلب للجهاز عبر `UsbManager.requestPermission`، وليس صلاحية
    Root. أضف intent-filter لـ `USB_DEVICE_ATTACHED` إذا لزم.
-   يجب بدء خدمة الالتقاط كـ Foreground قبل إنشاء الـ projection.

------------------------------------------------------------------------

# 7. تصميم الواجهات

الشاشات المقترحة:

1.  **Dashboard:** حالة المحرك، مستوى الإشارة، ومعلومات المسار.
2.  **Library / Player:** المصادر الداخلية وقائمة التشغيل **[تعديل 8]**.
3.  **App Manager:** قائمة التطبيقات وحالة قابلية الالتقاط.
4.  **Equalizer:** 31-Band وParametric EQ.
5.  **Mixer:** مستويات المصادر والقنوات.
6.  **Dynamics:** Compressor وLimiter.
7.  **Analyzer:** Spectrum وPeak/RMS.
8.  **Device Routing:** أجهزة USB وBluetooth والسماعات.
9.  **Settings:** معدل العينة، حجم المخزن المؤقت، وملفات الإعداد.

يجب أن تكون حالة الالتقاط ظاهرة للمستخدم بوضوح، مع شرح سبب عدم توفرها
عند الإمكان. ويجب أن تعرض الواجهة:

-   شرح موافقة MediaProjection قبل ظهور نافذة النظام **[تعديل 6]**.
-   تحذير الصوت المزدوج أثناء الالتقاط **[تعديل 3]**.
-   تنبيه زمن التأخير عند الالتقاط أو Bluetooth وعدم ملاءمتهما
    للفيديو **[تعديلات 5، 13]**.

------------------------------------------------------------------------

# 8. خطة التنفيذ **[تعديل 17]**

## المرحلة 1 --- Scaffold والبناء الأول

-   إنشاء مشروع Android Studio.
-   إعداد Kotlin وC++ وNDK وCMake.
-   إضافة Oboe.
-   بناء APK فارغ قابل للتثبيت.
-   إعداد GitHub Actions.

**بوابة النجاح:** نجاح بناء Debug APK من GitHub Actions وتثبيته على جهاز.

## المرحلة 2 --- إثبات المحرك

-   فتح Oboe stream.
-   توليد موجة اختبار 440 Hz.
-   إخراجها إلى مخرج الهاتف.
-   قياس XRun ومدة التشغيل.
-   اختبار 10 دقائق.
-   التعامل مع إيقاف/استئناف التطبيق وAudio Focus.

**بوابة النجاح:** تشغيل مستقر دون انهيار أو تقطيع متكرر، مع حفظ سجل
الاختبار.

## المرحلة 2B --- تجربة جدوى الالتقاط (مقدَّمة)

أُنقلت من المرحلة 5 لأنها أخطر ميزة وأكثرها اعتماداً على سياسات النظام،
ونتيجتها تحدد قيمة المنتج:

-   تدفق MediaProjection مع CaptureService.
-   AudioRecord بإعداد الالتقاط مع استثناء تطبيقنا.
-   إعادة تشغيل الصوت الملتقط عبر Oboe بدون DSP.
-   قياس زمن التأخير الفعلي ومعدل XRun/underrun.
-   اختبار على تطبيقين يسمحان بالالتقاط وتطبيق يمنعه.

**بوابة النجاح:** قرار موثق: هل زمن التأخير والاستقرار مقبولان للمسار B؟

## المرحلة 3 --- المصدر الداخلي وDSP

-   Audio Source Manager وفك الترميز وRing Buffer.
-   إضافة Gain وMetering أولاً.
-   إضافة EQ مع تنعيم المعاملات.
-   إضافة Compressor وLimiter.
-   اختبارات استجابة التردد والذروة (على المضيف ثم الجهاز).
-   التحقق من عدم حدوث clipping غير مقصود.

## المرحلة 4 --- إدارة الأجهزة

-   اكتشاف تغير أجهزة الصوت وإعادة فتح stream عبر `onErrorAfterClose`.
-   اختبار USB DAC، ومحاولة Exclusive وBit-perfect عند الدعم.
-   اختبار السماعات السلكية.
-   اختبار Bluetooth وقياس تأخيره.
-   توثيق الأجهزة ومعدلات العينة المختبرة.

## المرحلة 5 --- Capture Bridge الكامل

-   Drift Compensation واستقرار طويل للمسار B.
-   إدخال DSP في مسار الالتقاط.
-   إظهار حالات الالتقاط الصحيحة (متاح/ممنوع/فشل).
-   التعامل مع سحب الموافقة وانتهاء الجلسة.
-   (اختياري لاحقاً) التقاط لكل UID.

## المرحلة 6 --- الاستقرار والإصدار

-   اختبار الذاكرة والحرارة لمدة ساعة على الأقل.
-   اختبار جلسات طويلة.
-   اختبار فصل وإعادة توصيل USB.
-   اختبار التنقل بين مخارج الصوت.
-   إعداد توقيع Release وقواعد R8 (انظر القسم 10).
-   إنشاء Release APK بعد نجاح الاختبارات.

------------------------------------------------------------------------

# 9. اختبارات القبول **[تعديل 18]**

القيم الرقمية أدناه **مقترحة** كنقطة بدء وتُعدَّل بعد القياس الفعلي.

  الاختبار          معيار القبول
  ----------------- ------------------------------------------------------
  Native engine     يفتح stream ويغلقه بأمان 100 مرة متتالية دون تسرب
  Tone 440 Hz       قمة طيفية عند 440 Hz بتحليل FFT، وTHD+N أقل من -60 dB
  Stability         10 دقائق دون انهيار (و60 دقيقة في المرحلة 6)
  XRun              صفر XRun خلال 10 دقائق في الإعداد الافتراضي، وتسجيل
                    العدد ومقارنته بين الإعدادات
  Latency           قياس Round-trip/Output latency وتسجيله لكل جهاز
  DSP               انحراف استجابة EQ ضمن ±0.5 dB عن المصمَّم؛ Limiter لا
                    يتجاوز Ceiling؛ لا clipping عند أقصى رفع مع Pre-gain
  Parameter change  لا طقطقة مسموعة أو قفزات في الإشارة عند تحريك المعاملات
  Device switch     إعادة فتح stream خلال زمن قصير موثق دون انهيار
  USB DAC           تشغيل على الأجهزة المختبرة وتوثيق معدلات العينة
  Bluetooth         توجيه ناجح وفق إمكانيات الجهاز مع تسجيل التأخير
  Capture allowed   التقاط صوت تطبيق متوافق دون حلقة تغذية راجعة
  Capture blocked   إظهار عدم السماح دون ادعاء النجاح
  Capture drift     عدم تراكم تأخير أو انقطاع خلال 30 دقيقة التقاط
  Audio Focus       إيقاف/خفض/استئناف صحيح عند مكالمة أو تطبيق آخر
  Release build     عمل دوال JNI بعد R8 (لا UnsatisfiedLinkError)
  GitHub Actions    إنتاج APK قابل للتنزيل

لا تعتبر الاختبارات ناجحة قبل تنفيذها فعلياً وتسجيل الجهاز وإصدار Android
والنتيجة.

------------------------------------------------------------------------

# 10. GitHub Actions --- تصور سير البناء **[تعديل 19]**

يجب أن يحتوي workflow الفعلي على الخطوات التالية:

1.  Checkout للمستودع.
2.  إعداد JDK المتوافق.
3.  إعداد Android SDK وقبول التراخيص.
4.  تثبيت NDK وCMake عند الحاجة.
5.  إعداد Gradle مع التخزين المؤقت (cache) من Gradle Wrapper الموجود
    بالمشروع، والتأكد من صلاحية تنفيذ `gradlew`.
6.  تشغيل الاختبارات: `./gradlew testDebugUnitTest`.
7.  تشغيل `./gradlew --no-daemon clean assembleDebug`.
8.  رفع `app/build/outputs/apk/debug/app-debug.apk` كـ artifact.

مثال هيكل (يُعدَّل بإصدارات مؤكدة وقت التنفيذ):

``` yaml
name: android-build
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17          # طابق متطلبات AGP المختار
      - uses: gradle/actions/setup-gradle@v4
      - run: chmod +x gradlew
      - run: ./gradlew --no-daemon testDebugUnitTest
      - run: ./gradlew --no-daemon clean assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: app-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```

لا تستخدم `gradle-version` عشوائياً إذا كان المشروع يحتوي على Gradle
Wrapper؛ يجب أن يكون wrapper هو المرجع الأساسي لإصدار Gradle.

## Release والتوقيع

-   حفظ keystore وكلماته في GitHub Secrets، ولا يُرفع إلى المستودع.
-   إعداد `signingConfigs` يقرأ من متغيرات البيئة.
-   تفعيل R8 مع قواعد keep لدوال JNI وفئاتها، مثلاً:

``` text
-keepclasseswithmembernames class * {
    native <methods>;
}
```

------------------------------------------------------------------------

# 11. سجل الحالة الحالي

  العنصر                       الحالة المؤكدة
  ---------------------------- ----------------
  اسم AUDIO ENGINE PRO V1.1    معتمد
  Android 13+                  هدف معتمد
  بدون Root                    شرط معتمد
  USB / Bluetooth / Speakers   مخارج مستهدفة
  المعمارية العامة             مخططة ومصححة
  وحدات DSP                    محددة تصميمياً
  Android Studio project       لم يثبت إنشاؤه
  Gradle scaffold              لم يثبت إنشاؤه
  C++/Oboe engine              لم يثبت تنفيذه
  Audio Source Manager         لم يثبت تنفيذه
  Capture Bridge               لم يثبت تنفيذه
  اختبار USB DAC               لم يثبت تنفيذه
  GitHub Actions للمشروع       لم يثبت نجاحه
  APK                          لم يثبت إنتاجه

## العائق الرئيسي

الحد التقني في Android: لا يستطيع APK عادي دون Root فرض محركه على جميع
التطبيقات أو تجاوز سياسة منع الالتقاط أو كتم صوت التطبيق المصدر الأصلي.
يجب أن يبقى هذا القيد واضحاً في الواجهة والوثائق.

## الخطوة العملية التالية

إنشاء ملفات scaffold الحقيقية وفق الهيكل أعلاه، ثم إثبات بناء APK فارغ
عبر GitHub Actions قبل إضافة DSP. بعد ذلك يُنفذ اختبار Oboe 440 Hz بوصفه
أول إثبات تشغيل للمحرك، ثم تجربة جدوى الالتقاط (المرحلة 2B).

------------------------------------------------------------------------

# 12. مراجع رسمية

-   Android audio overview:
    https://developer.android.com/guide/topics/media/audio
-   Oboe documentation: https://github.com/google/oboe
-   Low-latency audio:
    https://developer.android.com/games/sdk/oboe/low-latency-audio
-   Audio playback capture:
    https://developer.android.com/media/platform/av-capture
-   Android audio architecture:
    https://source.android.com/docs/core/audio
-   USB host overview:
    https://developer.android.com/develop/connectivity/usb/host

------------------------------------------------------------------------

# 13. سجل التعديلات من V1.0 إلى V1.1

## أولاً: الأخطاء والتناقضات

  \#   التعديل                                                       الموضع
  ---- ------------------------------------------------------------- ----------------
  1    أذونات وخدمات Foreground الصحيحة (mediaProjection،            6، 6.1، 2
       mediaPlayback) ورفع compileSdk/targetSdk إلى 34+
  2    استثناء تطبيقنا من الالتقاط (excludeUid) لمنع حلقة التغذية    2.2
       الراجعة
  3    توثيق الصوت المزدوج وعدم القدرة على كتم المصدر الأصلي         1.2، 2.2، 7
  4    توضيح أن DSP لكل تطبيق يتطلب AudioRecord لكل UID وتأجيله      2.2، 3.1
  5    حدود الالتقاط: الاستخدامات المدعومة، لا مكالمات ولا DRM،      1.2
       وعدم ملاءمة الفيديو
  6    شرح نافذة موافقة MediaProjection التي تذكر الشاشة             2.2، 7
  7    قيود رؤية الحزم وQUERY_ALL_PACKAGES                           3.1

## ثانياً: الإضافات

  \#   الإضافة                                                       الموضع
  ---- ------------------------------------------------------------- ----------------
  8    Audio Source Manager: مصدر المسار A وفك الترميز والصيغ        2.1، 3.2
  9    Audio Focus وMediaSession وخدمة التشغيل وDoze                  3.6
  10   Lock-free Ring Buffer وتعويض الانحراف بين ساعة الالتقاط       2، 3.3
       وساعة المخرج
  11   إعادة فتح stream عبر onErrorAfterClose من خيط مستقل           3.3
  12   متطلبات DSP: Biquad وتنعيم المعاملات وDenormals وGain         3.4
       staging وLimiter وDither وFFT وتعريف Bass
  13   Bluetooth: زمن التأخير وBLUETOOTH_CONNECT وLE Audio           3.5
  14   USB: Shared مقابل Exclusive وBit-perfect في Android 14        3.5
  15   Oboe prefab وabiFilters ومحاذاة 16 KB وحذف حاجة OpenSL ES     4، 6
  16   هيكل مشروع كامل (wrapper وgitignore وproguard وبنية اختبارات) 5
  17   تقديم تجربة جدوى الالتقاط (المرحلة 2B)                        8
  18   معايير قبول رقمية وقابلة للقياس (مقترحة)                      9
  19   Workflow موسّع: اختبارات وcache وتوقيع Release وقواعد R8       10

**نهاية مواصفات AUDIO ENGINE PRO V1.1.**

هذا المستند هو مرجع التنفيذ. لا يعد بديلاً عن ملفات Gradle وManifest
وKotlin وC++ الفعلية اللازمة لبناء APK.
